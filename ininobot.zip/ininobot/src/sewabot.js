const sewabot = () => { 
	return `           
╔══❉ *𝐒𝐞𝐰𝐚 𝐁𝐨𝐭* ❉═══
║
╟⊱ *DAFTAR SEWA BOT* :
╟⊱ *Dana/Gopay  : 10K/Grup (Bulan)*
╟⊱ *Owner : 35K (Jadi Owner)*
╟⊱ *VIA :*
╟⊱ *DANA, GOPAY, PULSA*
╟⊱ *Pulsa Up 5K*
╠════════════════
╟⊱ *JIKA MINAT IKLAN HUB*
╟⊱ *wa.me/6288286421519*
╠════════════════
╟⊱ *Mau Beli Apikey?Nih Webnya*
╟⊱ *Mhankbarbar.tech*
╟⊱ *Api.vhtear.com*
╟⊱ *lolhuman.herokuapp.com*
║
╚══❉ *𝐍𝐢𝐧𝐨 𝐁𝐎𝐓* ❉════ 
`
}
exports.sewabot = sewabot